import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class main {
	 public static void main (String[] args) throws IOException {
		 if (args.length != 2) {
			    System.err.println("Please provide 2 arguments.");
			    System.exit(1);
		 }
		 
		 String keyFileName = args[0];
		 File keyFile = new File(keyFileName);
		 List<String> key = Files.readAllLines(keyFile.toPath(), StandardCharsets.UTF_8);
		 HashMap<Integer, String> stateDiction = new HashMap<>();
		 int indexofSmap = 0;
		 int i = 0;
		 while (i < key.size()){		 
			    String keyLine = key.get(i).trim();
			    if (keyLine.equals("")) {
			    	i++;
			    	continue; 	
		    	}
			    String[] keyFields = keyLine.split("\t");
			    String keyPos = keyFields[1];
			    if (stateDiction.containsValue(keyPos)){
		    		i++;	
			    }
			    else{
				    stateDiction.put(indexofSmap, keyPos);
		    		indexofSmap++;
		    		i++;
			    }  
		 }
		 stateDiction.put(indexofSmap, "start");
		 int stateSize = stateDiction.size();
		//Set up stateDiction Map
		 
		 int emission [][] = new int[key.size()][stateSize];
		 int transition[][] = new int[stateSize][stateSize-1];
		 HashMap<Integer, String> vocabDiction = new HashMap<>();
		 int indexofVmap = 0;
		 int j = 0;
		 String stateToken= "start";
		 while (j < key.size()){	 
			    String keyLine = key.get(j).trim();
			    if (keyLine.equals("")) {
			    	j++;
			    	stateToken = "start";
			    	continue; 	
		    	}
			    String[] keyFields = keyLine.split("\t");
			    String keyToken = keyFields[0];
			    String keyPos = keyFields[1];
			    int s=  (int) getKeyFromValue(stateDiction,stateToken);
			    int k = (int) getKeyFromValue(stateDiction,keyPos);
			    transition[s][k]++;
			    stateToken=keyPos;
			    
			    if (vocabDiction.containsValue(keyToken)){
		    		int h = (int) getKeyFromValue(vocabDiction,keyToken);
			    	emission[h][k]++;
			    	j++;	
			    }
			    else{
			    	vocabDiction.put(indexofVmap,keyToken);
			    	emission[indexofVmap][k]++;
			    	indexofVmap++;
		    		j++;
			    }  
		 }
		 for (int n = 0;n<indexofVmap;n++){
			 emission[n][45]=1;
		 }
		 for (int d = 0;d<46;d++){
			 emission[indexofVmap][d] = 1;
		 }
		 //set up VocabMap, emission map and transition map
		 
		 int[]helperArray = new int[46];
		 for(int c = 0;c<46;c++){
			 for (int r = 0;r<indexofVmap+1;r++){
			 helperArray[c]+=emission[r][c];
			 }
		 }
		 double[][] emissionHelper = new double[vocabDiction.size()+1][stateSize];
		 for(int r=0;r<stateSize;r++){
			 for (int l=0;l<vocabDiction.size()+1;l++){
				 emissionHelper[l][r] =  (double) (emission[l][r]*(1.0)/helperArray[r]);
			 }
		 }
		 double[][] emissionHelper2 = new double[stateSize][vocabDiction.size()+1];
		 for(int w = 0;w<vocabDiction.size()+1;w++){
			 for (int b = 0;b<stateSize;b++){
				 emissionHelper2[b][w]=emissionHelper[w][b];
			 }
		 }
		 //set up emission probability table
	  
		 int[]helperArray2 = new int[46];
		 for(int r = 0;r<46;r++){
			 for (int c = 0;c<45;c++){
			 helperArray2[r]+=transition[r][c];
			 }
		 }
		 double[][] transitionHelper = new double [stateSize][stateSize-1];
		 for(int r=0;r<stateSize;r++){
			 for (int l=0;l<(stateSize-1);l++){
				 transitionHelper[r][l] =  (double) (transition[r][l]*(1.0)/helperArray2[r]);
			 }
		 }
		 //set up transition probability table
	
		 int [] states = new int[45];
		 for (int st=0;st<45;st++){
			 states[st]=st;
		 }
		 //set up state array
		 
		 double []start_p = new double[45];
		 for (int sp = 0;sp<45;sp++){
			 start_p[sp] =transitionHelper[45][sp];
		 }
		 //set up start_p array
		 
		 System.out.println("Training all set up! Now reading the file!"); 
		 
		 String TestFileName = args[1];
		 File TestFile = new File(TestFileName);
		 File statText = new File("wsj_23.pos");
         FileOutputStream is = new FileOutputStream(statText);
         OutputStreamWriter osw = new OutputStreamWriter(is);    
         @SuppressWarnings("resource")
         Writer w = new BufferedWriter(osw);
         
		 List<String> Testkey = Files.readAllLines(TestFile.toPath(), StandardCharsets.UTF_8); 
		 int count = 0;
		 int innerCount = 0;
		 ArrayList<String> stringArray = new ArrayList<String>();
		 while (count<Testkey.size()){
			 String TestkeyLine = Testkey.get(count);		 
			 if (!TestkeyLine.equals("")) {
				 stringArray.add(TestkeyLine);
				 innerCount++;
				 count++;
			 }
			 else{
				 int [] obj= new int [innerCount];
				 for (int a = 0;a<innerCount;a++){
					 if (vocabDiction.containsValue(stringArray.get(a))){
				    		int v = (int)getKeyFromValue(vocabDiction,stringArray.get(a));
				    		obj[a] = v;
					 }else {
				    		int v = indexofVmap;
				    		obj[a] = v;
					 }
				 }
				 Viterbi2 v = new Viterbi2();
				 int [] returnarray= new int [innerCount];
				 double[][] emission_p = new double[45][innerCount];
				 for (int z =0;z<45;z++){
					 for(int y = 0;y<innerCount;y++){
						 emission_p[z][y]=emissionHelper2[z][obj[y]];
					 }
				 }
				 returnarray = v.forwardViterbi(obj, states, start_p, transitionHelper, emission_p);
				 if (returnarray.length<=0){ // caused by transition probability equals zero
					for (int e = 0;e<innerCount;e++){
					w.write(stringArray.get(e)+"\t"+"NN"+"\n");}
				 } 
				 for (int m =0;m<returnarray.length;m++){
					 w.write(stringArray.get(m)+"\t"+stateDiction.get(returnarray[m])+"\n");
				 }
				 w.write("\n"); 
				 count++; 
				 innerCount = 0;
				 stringArray.clear();
				 
			 }
			
		}
		System.out.println("Code ends. Please see the output file."); 
		w.close();	 		
					   
	 }	    	    	
			    	 
	 public static Object getKeyFromValue(Map<Integer, String> hm, Object value) {
		    for (Object o : hm.keySet()) {
		      if (hm.get(o).equals(value)) {
		        return o;
		      }
		    }
		    return null;
		  }
	     
	 
}
