import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.text.*;


public class MEMMmain {
	public static void main(String[] args) throws Exception {
       
		// Build feature from training.txt
		System.out.println("Start reading from training.txt...");
		String pathRead = "training.txt";
		String pathWrite = "training_feature-enhanced.txt";
		FeatureBuilder t = new FeatureBuilder();
		t.readFile(pathRead, pathWrite);
		
        //Train a model from training_feature-enhanced.txt
		System.out.println("Training the model...");
		String dataFileName = "training_feature-enhanced.txt";
		String modelFileName = "Model.MEtrain";
		MEtrain trainModel = new MEtrain();
		trainModel.train(dataFileName, modelFileName);
		
        // Build feature from words.txt
		System.out.println("Start reading from words.txt...");
		FeatureBuilder2 test = new FeatureBuilder2();
		String testFile = "words.txt";
		String testProcessedFile = "words_feature-enhanced.txt";
		test.readFile(testFile, testProcessedFile);
		
		//Tagging words.txt by using the model
		System.out.println("Tagging with model...");
		String resultFileName = "response.txt";
		MEtag modelTagger = new MEtag();
		modelTagger.tag(testProcessedFile,modelFileName,resultFileName);	
		
	}

}