import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.*;
import java.math.*;


public class Naive_Bayes {

	private  static Map<String, Integer> countClass = new HashMap<>();
	private  static Map<String, HashMap<String, Integer>> countWord = new HashMap<>();
	private static int countClassN;
	private static int countClassP;
	private static int countAllWords;
	private static double psentenceN;
    private static 	double psentenceP;
    private static List<String> symbols= new ArrayList<String>();



	public static void main (String[] args) throws IOException {
        if (args.length != 2) {
            System.err.println("PosTagger takes 2 arguments:  java Naive_Bayes training.txt words.txt");
            System.exit(1);
        }

        trainNaiveBayes(args[0]);

        /*List<String> test= new ArrayList<>();
        test.add("i");
        test.add("think");
        test.add("this");
        test.add("class");
        test.add("is");
        test.add("awful");
        test.add("it");
        test.add("'s");
        test.add("not");
        test.add("funny");
        test.add("at");
        test.add("all");
        runNaiveBayes(test);*/

   
        /*System.out.println(countClassN);
        System.out.println(countClassP);
        System.out.println(pNegative);
        System.out.println(pPositive);
        System.out.println(countAllWords);*/
       tagging(args[1]);

    }

    private static void trainNaiveBayes(String trainingFilePath) throws IOException {

    	File trainingFile = new File(trainingFilePath);
        List<String> wordTagPairs = Files.readAllLines(trainingFile.toPath(), StandardCharsets.UTF_8);

        for (int i=0; i<wordTagPairs.size(); i++){

        	String wordTag=wordTagPairs.get(i).trim();
        	String word="";
        	String tag="";
        	if (!wordTag.equals("")){
        		String [] field=wordTag.split("\t");
        		if (field.length !=2){
        			System.err.println ("format error in word-tag pair at line " + i + ": " + wordTag);
                    System.exit(1);
        		}

        		word= field[0];
        		tag=field[1];

        		if (!word.equals(tag)){
        			if (!countWord.containsKey(word)){
        				countWord.put(word,new HashMap<>());
        			}
        			HashMap<String, Integer> countTemp= countWord.get(word);
        			if (!countTemp.containsKey(tag)){
        				countTemp.put(tag,1);
        			} else {
        				countTemp.put(tag,countTemp.get(tag)+1);
        			}
        			if (!countClass.containsKey(tag)){
        				countClass.put(tag,1);
        			} else{
        				countClass.put(tag,countClass.get(tag)+1);
        			}


        		} else {
                    symbols.add(word);

                }
        	}


        }

        countClassP=countClass.get("P");
        countClassN=countClass.get("N");
        countAllWords=countWord.size();


    }

    private static void tagging(String targetFilePath) throws IOException {
    	File targetFile = new File(targetFilePath);
        List<String> words = Files.readAllLines(targetFile.toPath(), StandardCharsets.UTF_8);

        List<String> sentence = new ArrayList<>();
        List<Map.Entry<String, String>> results = new ArrayList<>();

        for(String word:words){
        	word=word.trim();
        	if (word.equals("")){
        		results.addAll(runNaiveBayes(sentence));
        		results.add(new AbstractMap.SimpleEntry<String, String>("", ""));
                sentence.clear();
        		} else{
        			sentence.add(word);	
        	}
        }

        if (!sentence.isEmpty()){
        	results.addAll(runNaiveBayes(sentence));
        }

        PrintWriter pw=null;
        try {
        	pw = new PrintWriter(new FileWriter( "response.txt", false));
        

        } catch (IOException e) {
            e.printStackTrace();
        }
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> entry : results) {
            sb.append(entry.getKey() + "\t" + entry.getValue() + "\n");
        }
        pw.append(sb.toString());
        pw.close();

    }



    private static List<Map.Entry<String, String>> runNaiveBayes(List<String> sentence){

    	int size=sentence.size();
    	String tagNP="";
    	double pN=1.0;
    	double pP=1.0;
    	double pwordN;
    	double pwordP;
    	double psentenceN;
    	double psentenceP;

    	for(int i=0; i<size; i++ ){
    		if (countWord.containsKey(sentence.get(i))){
    			if (countWord.get(sentence.get(i)).containsKey("P")){
    				pwordP=(1+countWord.get(sentence.get(i)).get("P"))/(double)(countAllWords+countClass.get("P"));
    			} else {
    				pwordP=1/(double)(countAllWords+countClass.get("P"));
    			}

    			if (countWord.get(sentence.get(i)).containsKey("N")){
    				pwordN=(1+countWord.get(sentence.get(i)).get("N"))/(double)(countAllWords+countClass.get("N"));
    			} else {
    				pwordN=1/(double)(countAllWords+countClass.get("N"));
    			}
    		} else{
    			continue;
    		}
    		
    		pP=pP*pwordP;
    		pN=pN*pwordN;

    	}

    	psentenceP=Math.log(countClassP/(double)(countClassN+countClassP)*pP);
    	psentenceN=Math.log(countClassN/(double)(countClassN+countClassP)*pN);

    	if (psentenceN>psentenceP){
    		tagNP="N";
    	} else{
    		tagNP="P";
    	}


        List<Map.Entry<String, String>> result = new ArrayList<>();

    	for (int i=0; i<size; i++){
            /*if (symbols.contains(sentence.get(i))){
                result.add(new AbstractMap.SimpleEntry<>(sentence.get(i), sentence.get(i)));
            } else{*/
                result.add(new AbstractMap.SimpleEntry<>(sentence.get(i), tagNP));
            //}	
    	}

    	return result;




    }
}














