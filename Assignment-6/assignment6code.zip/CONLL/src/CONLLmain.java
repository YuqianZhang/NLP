public class CONLLmain {
	public static void main(String[] args) throws Exception {
       
		// Build feature from CONLL_train.pos-chunk-name
		System.out.println("Start reading from CONLL_train.pos-chunk-name...");
		String pathRead = "CONLL_train.pos-chunk-name";
		String pathWrite = "CONLL_train_feature_enhanced.txt";
		FeatureBuilder t = new FeatureBuilder();
		t.readFile(pathRead, pathWrite);
	
        //Train a model from CONLL_train_feature_enhanced.txt
		System.out.println("Training the model...");
		String dataFileName = "CONLL_train_feature_enhanced.txt";
		String modelFileName = "Model.MEtrain";
		MEtrain trainModel = new MEtrain();
		trainModel.train(dataFileName, modelFileName);
		
        // Build feature from CONLL_dev.pos-chunk
		System.out.println("Start reading from CONLL_test.pos-chunk...");
		FeatureBuilder2 test = new FeatureBuilder2();
		String testFile = "CONLL_test.pos-chunk";
		String testProcessedFile = "CONLL_test_feature_enhanced(extra).txt";
		test.readFile(testFile, testProcessedFile);
		
		//Tagging CONLL_dev_test.name by using the model
		System.out.println("Tagging with model...");
		String resultFileName = "CONLL_test(extra).name";
		MEtag modelTagger = new MEtag();
		modelTagger.tag(testProcessedFile,modelFileName,resultFileName);	
	}

	
}