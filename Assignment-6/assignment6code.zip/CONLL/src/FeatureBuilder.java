import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;


public class FeatureBuilder {
	private Scanner reader;
	private PrintWriter writer;
	private ArrayList<ArrayList<String>> a;
	//Pattern p = Pattern.compile("[^a-z0-9 ]", Pattern.CASE_INSENSITIVE);
	public HashMap<Integer, String> allLastDiction = new HashMap<>();
	public HashMap<Integer, String> femaleFirstDiction = new HashMap<>();
	public HashMap<Integer, String> maleFirstDiction = new HashMap<>();
	
	
	
	public FeatureBuilder() throws IOException {
		a = new ArrayList<ArrayList<String>>();
		File keyFile = new File("dist.all.last");
		List<String> key = Files.readAllLines(keyFile.toPath(), StandardCharsets.UTF_8);
		int i = 0;
		while (i < key.size()){
			String keyLine = key.get(i).trim();
			String[] keyFields = keyLine.split("      ");
			String keyPos = keyFields[0];
			allLastDiction.put(i, keyPos);
			i++;
		}
		File femaleFile = new File("dist.female.first");
		List<String> femaleKey = Files.readAllLines(femaleFile.toPath(), StandardCharsets.UTF_8);
		int j = 0;
		while (j < femaleKey.size()){
			String femalekeyLine = femaleKey.get(j).trim();
			String[] femalekeyFields = femalekeyLine.split("      ");
			String femalekeyPos = femalekeyFields[0];
			femaleFirstDiction.put(j, femalekeyPos);
			j++;
		}
		File maleFile = new File("dist.male.first");
		List<String> maleKey = Files.readAllLines(maleFile.toPath(), StandardCharsets.UTF_8);
		int k = 0;
		while (k < maleKey.size()){
			String malekeyLine = maleKey.get(k).trim();
			String[] malekeyFields = malekeyLine.split("      ");
			String malekeyPos = malekeyFields[0];
			maleFirstDiction.put(k, malekeyPos);
			k++;
		}	
		
		System.out.println("ALL hashtables are ready!");
	}

	public void readFile(String pr, String pw) throws Exception {
		writer = new PrintWriter(pw);
		reader = new Scanner(Paths.get(pr));
		String line = "";
		
		while (reader.hasNextLine()) {
			line = reader.nextLine();
			if (line.trim().length() == 0) {
				int len = a.size();
				for (int i = 0; i < len; i++) {
					writer.print(a.get(i).get(0) + "\t");
					//add firstUpper feature here
					writer.print("firstUpper=");
					if (Character.isUpperCase(a.get(i).get(0).charAt(0)))
						writer.print("yes" + "\t");
					else
						writer.print("no" + "\t");
					//add inNamelist feature here
					writer.print("inNamelist=");
					if (inNamelist(a.get(i).get(0).toUpperCase()))
						writer.print("yes" + "\t");
					else
						writer.print("no" + "\t");
					writer.print("preToken=");
					if (i > 0)
						writer.print(a.get(i - 1).get(0) + "\t");
					else
						writer.print("@@\t");
					writer.print("postToken=");
					if (i < len - 1)
						writer.print(a.get(i + 1).get(0) + "\t");
					else
						writer.print("#\t");
					writer.print("curPOS=" + a.get(i).get(1) + "\t");
					writer.print("prePOS=");
					if (i > 0)
						writer.print(a.get(i - 1).get(1) + "\t");
					else
						writer.print("@@\t");
					writer.print("postPOS=");
					if (i < len - 1)
						writer.print(a.get(i + 1).get(1) + "\t");
					else
						writer.print("#\t");
					
/*					writer.print("preCur=");
					if (i > 0)
						writer.print(a.get(i - 1).get(1) + "+" + a.get(i).get(1) + "\t");
					else
						writer.print("@@" + "+" + a.get(i).get(1) + "\t");
					writer.print("curPost=");
					if (i < len - 1)
						writer.print(a.get(i).get(1) + "+" + a.get(i + 1).get(1) + "\t");
					else
						writer.print(a.get(i).get(1) + "+" + "#\t");  */
					writer.print("curTag=" + a.get(i).get(2) + "\t");
					writer.print("preTag=");
					if (i > 0)
						writer.print(a.get(i - 1).get(2) + "\t");
					else
						writer.print("@@\t");
				/*	writer.print("postTag=");
					if (i < len - 1)
						writer.print(a.get(i + 1).get(2) + "\t");
					else
						writer.print("#\t");   */
					writer.print("preName=");
					if (i > 0)
						writer.print(a.get(i - 1).get(3) + "\t");
					else
						writer.print("@@\t");
					
					writer.print(a.get(i).get(3) + "\n");//the current NameTag
					
					
				}
				a.clear();
				writer.println();
			} else {
				String[] tokens = line.split("\t");
				ArrayList<String> list = new ArrayList<String>();
				for (int i = 0; i < tokens.length; i++) {
					list.add(tokens[i]);
				}
				a.add(list);

			}
		}
		reader.close();
		writer.close();
		System.out.println("FeatureBuilder completed, the output file is "+pw);
	}

	public boolean inNamelist(String s) {
		int d = 0;
		while (d<maleFirstDiction.size()){
			if (maleFirstDiction.get(d).equalsIgnoreCase(s))
				return true;
			d++;
		}
		int c = 0;
		while (c<femaleFirstDiction.size()){
			if (femaleFirstDiction.get(c).equalsIgnoreCase(s))
				return true;
			c++;
		}
		int b = 0;
		while (b<allLastDiction.size()){
			if (allLastDiction.get(b).equals(s))
				return true;
			b++;
		}
		return false;
	}
	
}